import React from 'react';
function Calendario() {
  return (
    <div className="page">
      <h1>Calendário AgroPlanner</h1>
    </div>
  );
}
export default Calendario;
