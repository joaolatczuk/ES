import React from 'react';
function Forum() {
  return (
    <div className="page">
      <h1>Fórum</h1>
    </div>
  );
}
export default Forum;
