import React from 'react';
import AppRouter from './pages/AppRouter';


function App() {
  return <AppRouter />;
}
export default App;
